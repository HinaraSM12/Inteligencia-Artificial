/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package fis_horneado;

import interfaz.HorneadoUI;
import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.plot.JFuzzyChart;
/**
 *
 * @author USER
 */
public class FIS_Horneado {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        HorneadoUI e = new HorneadoUI();
        e.setVisible(true);
    }

    public String calcularTemperatura(double humedad, double intensidad, double volumen) {
        // Carga el archivo de lenguaje de control difuso 'FCL'
        String fileName = "src/fis_horneado/FCL_Horneado.fcl";
        FIS fis = FIS.load(fileName, true);
        
        // En caso de error
        if (fis == null) {
            System.err.println("No se puede cargar el archivo: '" + fileName + "'");
            return "";
        }
        
        // Establecer las entradas del sistema
        fis.setVariable("humedad", humedad);
        fis.setVariable("intensidad", intensidad);
        fis.setVariable("volumen", volumen);

        // Inicia el funcionamiento del sistema
        fis.evaluate();

        // Muestra los gráficos de las variables de entrada y salida
        JFuzzyChart.get().chart(fis.getFunctionBlock("horneado"));
        
             
        // Imprime el valor concreto de salida del sistema
        double salida = fis.getVariable("temperatura").getLatestDefuzzifiedValue();
        
        // Muestra cuanto peso tiene la variable de salida en cada CD de salida
        double pertenenciaBaja = fis.getVariable("temperatura").getMembership("baja");
        double pertenenciaMedia = fis.getVariable("temperatura").getMembership("media");
        double pertenenciaAlta = fis.getVariable("temperatura").getMembership("alta");
        
        String temperaturaRecomendada = "";
        
        if (pertenenciaBaja >= pertenenciaMedia && 
                pertenenciaBaja >= pertenenciaAlta) {
            temperaturaRecomendada = "baja";
        } else if (pertenenciaMedia >= pertenenciaBaja && 
                pertenenciaMedia >= pertenenciaAlta) {
            temperaturaRecomendada = "media";
        } else if (pertenenciaAlta >= pertenenciaBaja && 
                pertenenciaAlta >= pertenenciaMedia) {
            temperaturaRecomendada = "alta";
        }
        
        
        // Muestra las reglas activadas y el valor de salida de cada una despues de aplicar las operaciones lógicas
        StringBuilder reglasUsadas = new StringBuilder();
        reglasUsadas.append("Reglas Usadas:\n");
        fis.getFunctionBlock("horneado").getFuzzyRuleBlock("No1").getRules().stream().filter(r -> (r.getDegreeOfSupport() > 0)).forEachOrdered(r -> {
            reglasUsadas.append(r.toString()).append("\n");
        });
        
        return ("Para los valores de entrada la temperatura recomendada para el postre que deseas es: " + temperaturaRecomendada + " " + String.format("%.2f", salida) + "°C"+
                "\n" + reglasUsadas.toString());
        
    }
    
}
